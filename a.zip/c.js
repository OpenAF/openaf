//@ 'S'tar"t"

var name = "Nuno"

//# name == "Nuno" && 'nuno' == "nuno"
//? name

//[ print "hello" 'hi'
tprint("Hello {{name}}!")
//] print "hello" 'hi'

//@ 'E'n"d"